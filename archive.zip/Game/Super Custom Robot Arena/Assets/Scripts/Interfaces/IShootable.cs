﻿using UnityEngine;
using System.Collections;

public interface IShootable {
	void Shoot();
}
